let menu = document.querySelectorAll('nav a');
menu.forEach(item => {
    item.addEventListener('click',e =>{
        document.querySelectorAll('body > div').forEach(i => i.style.display = 'none');
        document.querySelector(item.getAttribute('href')).style.display = 'block';
    });
});