document.querySelectorAll('.next,.prew').forEach(i=>i.addEventListener('click',e=>{
    let slide;
    if(e.target.getAttribute('class')=='next'){
        slide = document.querySelector('.slider .slide:first-child');
        document.querySelector('.slider').append(slide);
    }else{
        slide = document.querySelector('.slider .slide:last-child');
        document.querySelector('.slider').prepend(slide);
    }
}));