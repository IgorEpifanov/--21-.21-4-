"use strict";

// Глобальный игровой объект
window.game = {
    player: document.getElementById('player'),
    start: document.getElementById('start'),
    start_screen: document.querySelector('.start_screen'),
    play_screen: document.querySelector('.play_screen'),
    game_over: document.querySelector('.game_over'),
    life: document.querySelector('#life b'),
    check: document.querySelector('#check b'),
    game_over_check: document.querySelector('.game_over b'),
    lastCheckElement: document.querySelector('.lastcheck'),
    enemy: {
        spawnTime: 0,
        spawnDelay: 1000,
        spawnLimit: 999,
        collision: []
    },
    main: time => {
        let pos, projectile, pos2, enemy;

        // Игрок двигается
        pos = parseFloat(game.player.style.left);
        if(game.player.left) pos -= 0.5;
        if(game.player.right) pos += 0.5;
        if(pos<10) pos = 10;
        if(pos>90) pos = 90;
        game.player.style.left = pos+'%';

        // Игрок стреляет
        if(game.player.fire)
            if(game.player.fireTime<time-game.player.fireDelay){
                game.player.fireTime = time;
                game.addProjectile('player');
            }

        // Нашествие захватчиков
        if(game.state=='play'){
            if(game.enemy.collision.length<game.enemy.spawnLimit)
                if(game.enemy.spawnTime<time-game.enemy.spawnDelay){
                    game.enemySpawn();
                    game.enemy.spawnTime = time;
                }
        }

        // Захватчики летят, и стреляют
        if(game.state=='play'){
            for(let i=0,n=game.enemy.collision.length;i<n;i++){
                if(!(enemy = game.enemy.collision[i])) continue;
                pos = parseFloat(enemy.style.top)+1;
                
                if(pos>window.innerHeight+32) pos = false;
                
                if(pos===false){
                    game.enemy.collision[i].remove();
                    game.enemy.collision[i] = null;
                    game.life.count--;
                }else{
                    enemy.style.top = pos+'px';
                    
                    if(pos<window.innerHeight-200)
                        if(Math.round(Math.random()*1000)<5)
                            game.addProjectile(enemy);
                }
            }
        }


        // Пули летят
        for(let i=0,n=game.projectileCollection.length;i<n;i++){
            if(!(projectile = game.projectileCollection[i])) continue;
            pos = parseFloat(projectile.style.top);
            
            if(projectile.id=='player_projectile'){
                if(pos<-32) pos = false; else pos -= 10;
            }else{
                if(pos>window.innerHeight+32) pos = false; else pos += 10;
            }

            if(pos===false){
                game.projectileCollection[i].remove();
                game.projectileCollection[i] = null;
            }else
                projectile.style.top = pos+'px';
        }

        // Проверка столкновений пуль
        for(let i=0,n=game.projectileCollection.length;i<n;i++){
            if(!(projectile = game.projectileCollection[i])) continue;
            pos = game.getPosition(projectile);
            pos.radius = 8;

            switch(game.state){
                case 'start_screen':
                    pos2 = game.getPosition(game.start);
                    pos2.radius = 72;
                    if(game.checkCollision(pos,pos2)){
                        game.addExplosion(game.start);
                        game.state = 'play';
                        game.start_screen.style.opacity = 0;
                        game.play_screen.style.opacity = 1;
                        
                        game.check.count = 0;
                        game.life.count = 3;
                        game.lifeCheck = 0;
                    }
                break;
                case 'play':
                    if(projectile.id=='player_projectile'){
                        for(let i=0,n=game.enemy.collision.length;i<n;i++){
                            if(!(enemy = game.enemy.collision[i])) continue;
                            pos2 = game.getPosition(enemy);
                            pos2.radius = 16;
                            if(game.checkCollision(pos,pos2)){
                                game.check.count += 100;
                                game.lifeCheck += 100;
                                game.addExplosion(enemy);
                                game.enemy.collision[i].remove();
                                game.enemy.collision[i] = null;
                            }
                        }
                    }else{
                        pos2 = game.getPosition(game.player);
                        pos2.radius = 32;
                        if(game.checkCollision(pos,pos2)&&!game.player.godmod){
                            game.life.count--;
                            game.player.godmod = 21;
                            game.addExplosion(game.player);
                            game.player.style.opacity = 0;
                            game.player.godmodTimer = setInterval(e=>{
                                game.player.style.opacity = game.player.style.opacity=='1'?0:1;
                                game.player.godmod--;
                                if(!game.player.godmod)
                                    clearInterval(game.player.godmodTimer);
                            },100);
                        }
                    }
                break;
            }

            // Проверка столкновений кораблей
            if(game.state=='play')
                for(let i=0,n=game.enemy.collision.length;i<n;i++){
                    if(!(enemy = game.enemy.collision[i])) continue;
                    pos = game.getPosition(enemy);
                    pos.radius = 32;
                    pos2 = game.getPosition(game.player);
                    pos2.radius = 32;
                    if(game.checkCollision(pos,pos2)&&!game.player.godmod){
                        game.check.count += 100;
                        game.lifeCheck += 100;
                        game.life.count--;
                        game.player.godmod = 21;
                        game.addExplosion(enemy);
                        game.enemy.collision[i].remove();
                        game.enemy.collision[i] = null;
                        game.addExplosion(game.player);
                        game.player.style.opacity = 0;
                        game.player.godmodTimer = setInterval(e=>{
                            game.player.style.opacity = game.player.style.opacity=='1'?0:1;
                            game.player.godmod--;
                            if(!game.player.godmod)
                                clearInterval(game.player.godmodTimer);
                        },100);
                    }
                }

        }

        // Game over
        if(game.state=='play')
            if(game.life.count<=0){
                game.state = 'game_over';
                game.play_screen.style.opacity = 0;
                game.game_over.style.opacity = 1;
                game.game_over_check.innerText = game.check.count;
                if(game.lastcheck<game.check.count){
                    localStorage.setItem('check',game.check.count);
                    game.lastcheck = game.check.count;
                }
                setTimeout(e=>{
                    game.state = 'start_screen';
                    game.game_over.style.opacity = 0;
                    game.start_screen.style.opacity = 1;
                    for(let i=0,n=game.projectileCollection.length;i<n;i++){
                        if(!(projectile = game.projectileCollection[i])) continue;
                        game.projectileCollection[i].remove();
                        game.projectileCollection[i] = null;
                    }
                },5000);
            }

        // Бонусная жизнь
        if(game.state=='play')
            if(game.lifeCheck>=2000){
                game.lifeCheck -= 2000;
                game.life.count++;
            }

        // Взрываем все
        if(game.state=='game_over'){
            for(let i=0,n=game.enemy.collision.length;i<n;i++){
                if(!(enemy = game.enemy.collision[i])) continue;
                game.addExplosion(enemy);
                game.enemy.collision[i].remove();
                game.enemy.collision[i] = null;
            }
        }

        // Очистка
        if(game.garbageTimer<time-1000){
            game.projectileCollection = game.projectileCollection.filter(i=>i);
            game.enemy.collision = game.enemy.collision.filter(i=>i);
            game.garbageTimer = time;
        }

        game.check.innerText = game.check.count;
        game.life.innerText = game.life.count;
        game.lastCheckElement.innerText = game.lastcheck;

        window.requestAnimationFrame(game.main);
    },
    projectileCollection: [],
    addProjectile: object => {
        let projectile, pos;

        if(object=='player'){
            pos = game.getPosition(game.player);
            projectile = document.createElement('div')
            projectile.id = 'player_projectile';
            projectile.style.top = pos.y+'px';
            projectile.style.left = (pos.x-10)+'px';
            game.projectileCollection.push(projectile);
            
            document.body.append(projectile);
            projectile = document.createElement('div')
            projectile.id = 'player_projectile';
            projectile.style.top = pos.y+'px';
            projectile.style.left = (pos.x+10)+'px';
            game.projectileCollection.push(projectile);
            document.body.append(projectile);
        }else{
            projectile = document.createElement('div')
            projectile.id = 'enemy_projectile';
            pos = game.getPosition(object);
            projectile.style.top = pos.y+'px';
            projectile.style.left = pos.x+'px';
            game.projectileCollection.push(projectile);
            document.body.append(projectile);
        }

    },
    addExplosion: object => {
        let explosion = document.createElement('img'),
            pos = game.getPosition(object);
        explosion.id = 'explosion';
        explosion.src = 'img/explosion.gif';
        explosion.style.top = pos.y+'px';
        explosion.style.left = pos.x+'px';
        document.body.append(explosion);
        setTimeout(e=>{ explosion.remove(); },500);  
    },
    enemySpawn: e => {
        let enemy = document.createElement('div'),
            pos = Math.round(Math.random()*(90-10)+10);
        enemy.id = 'enemy';
        enemy.style.top = '-32px';
        enemy.style.left = pos+'%';
        game.enemy.collision.push(enemy);
        document.body.append(enemy);
    },
    getPosition: element => {
        let rect = element.getBoundingClientRect();
        return { 
            x: rect.x+rect.width/2,
            y: rect.y+rect.height/2
        };
    },
    checkCollision: (A,B) => {
        const distance = Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2));
        return distance < A.radius + B.radius;
      }
};
game.state = 'start_screen';
game.player.left = false;
game.player.right = false;
game.player.fire = false;
game.player.fireTime = 0;
game.player.fireDelay = 300;
game.garbageTimer = 0;
game.player.godmod = 0;

game.check.count = 0;
game.life.count = 0;
game.lifeCheck = 0;

game.lastcheck = localStorage.getItem('check')??0;

game.main();