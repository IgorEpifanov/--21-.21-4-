"use strict";

(document=>{

    let control = e => {

        switch(e.code){
            case 'KeyA': case 'ArrowLeft': // Налево
                if(e.type=='keydown'){
                    game.player.classList.add('left');
                    game.player.classList.remove('right');
                    game.player.left = true;
                    game.player.right = false;
                }else{
                    game.player.classList.remove('left');
                    game.player.left = false;
                }

            break;
            case 'KeyD': case 'ArrowRight': // Направо
                if(e.type=='keydown'){
                    game.player.classList.add('right');
                    game.player.classList.remove('left');
                    game.player.left = false;
                    game.player.right = true;
                }else{
                    game.player.classList.remove('right');
                    game.player.right = false;
                }
            break;
            case 'Space': // Огонь
                game.player.fire = e.type=='keydown';
            break;
        }
    }

    document.addEventListener('keydown',control);
    document.addEventListener('keyup',control);

})(document);
